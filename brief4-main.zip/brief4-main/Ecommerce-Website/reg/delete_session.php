<?php
session_unset();
